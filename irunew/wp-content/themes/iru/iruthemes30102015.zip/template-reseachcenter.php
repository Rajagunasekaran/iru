<?php
	/**
 * Template Name: Research Center
 * 
 * @package bootstrap-basic
 */

get_header();

/**
 * determine main column size from actived sidebar
 */
$main_column_size = bootstrapBasicGetMainColumnSize();
echo research_types();
?> 
	
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/2.2.2/isotope.pkgd.min.js"></script>
    		<div class="col-md-12 col-sm-12 content-area researchcenters" id="main-column">
					<div class="contentpanel">
						<main id="main" class="site-main" role="main">
							<?php 
							while (have_posts()) {
								the_post();

							?>
								<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
									<div class="entry-content">
										<?php //the_content(); ?> 
										
                                        
                                        <div class="iru_statistics">
                                          <?php 
										  	  $args = array('posts_per_page' => -1,'post_type' => 'research_strengths','post_staus' => 'publish');
										      query_posts($args);
											  global $post;
											  $content = '';
											  if(have_posts()):
											  	while(have_posts()): the_post();
												
												 $university = get_field('box_universities');	
												 $research_type = get_field('research_type');
												 
												 
												 
												 $univ = '';
												 $univ_image = '';
												 
												 
												
												if(!empty($university)){  
													 foreach($university as $items)	{
														$university_logo = get_field('university_logo',$items->ID);
														$website = get_field('website',$items->ID);
														if($items->post_title != ''){
															if($univ != ''){
																$univ .= ', <a href="'.$website.'" target="_blank" >'.$items->post_title.'</a>';	
															}else{
																$univ .= ' - <a href="'.$website.'" target="_blank" >'.$items->post_title.'</a>';
															}
														}
														
														$univ_image .= '<a href="'.$website.'" target="_blank" ><img src="'.$university_logo.'" alt="'.$items->post_title.'" /></a>';
													 }
												}
												 
												 if($univ_image != '')
												 	$univ_image = '<div class="universities">'.$univ_image.'</div>';
												 
												 //$field_obj = get_sub_field_object('research_type');
												// $choice = $field_obj['choices'];
												 
												$content .= '<div class="research_info '.$research_type.'" data-category="'.$research_type.'">
															
															  <h2 class="research_title">'.get_the_title().'<span>'.$univ.'</span></h2>
															  <div class="rc_information">'.$post->post_content.$univ_image.'</div>
														  </div>';
												
												endwhile;
												wp_reset_query();
											  endif;	
											 echo '<div class="isotope">'.$content.'</div>';  
										  ?>   
                                        
                                        </div>
                                        
									</div><!-- .entry-content -->
								</article><!-- #post-## -->
							<?php 
								} //endwhile;
							?> 
							
						</main>
						
					</div>
				</div>
            <script type="text/javascript">
				jQuery(document).ready(function(e) {
                    jQuery('.research_Types li').each(function(){
						if(jQuery(this).hasClass('active')){
							jQuery(this).find('a').trigger('click');
							
						}
					});
                });
			</script>	    
<?php get_footer(); ?> 